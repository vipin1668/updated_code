'use strict';

const ContentServices  = require('./ContentService');

module.exports = {
    ContentServices:ContentServices
}