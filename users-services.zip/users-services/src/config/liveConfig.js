module.exports = {
  mongoURI:
    "mongodb://footprint:cQZMR[LqbtB8E@3.7.83.168:27089/grocery-live-user-service?authSource=admin",

  expressPort: 3061,
  secureAPI: false,
  siteUrl: "http://3.7.83.168:3061",
  rootPath: "/home/ubuntu/Projects/Grocery/users-service",

  // API gateway base url
  apiGatewayUrl: "http://3.7.83.168:3060",

  // database name
  databaseName: "grocery-live-user-service",

  // project name
  siteTitle: "Athwas",

  // JWT Secret Key
  jwtSecretKey: "GroceryAppusers",

  // Login session expiration setting for App Users
  appLoginSessionExpiryTime: 722 * 60, // in minutes
  appLoginSessionAuthCheck: true,

  timeZone: "Asia/Kolkata",

  // Redis Config Options. Ref: https://www.npmjs.com/package/ioredis
  redisConfigOpts: {
    port: 6379,
    host: "127.0.0.1",
    prefix: "grocery_user",
    password:
      "beLJzkzJWmY58bhnq62TKKDawlx1z97yVeLQOn3ZNFG1qrpwaL8Qe9cZzlWi7PcQp1+0ils9v/ahwofY",
    db: 4,
  },

  // api key for web service access
  apiAccessKey: "Hakfwb{h2u24[dew",

  apiAccessKeyForOther: "B5s23ux{hd54]",

  //allow to check api key
  validateApiAccess: true,

  // when call services internally, use this key instead of token
  internalApiAccessKey: "3x[aR45]YJRJS}45",

  // api key for node-geocoder npm package
  geocoderApiKey: "AIzaSyCnHXmtGqz7eOZg2rW9U20KDit1tRF6rhU",

  // FCM server key for Andriod push notifications (refrence: https://www.npmjs.com/package/fcm-push)
  fcmServerKey:
    "AAAAkxV8TIA:APA91bExA1_-uQan5cNpzx1Bs1YQVa2oK-321M108wyp42MAj7p5G2IzP-y0N2qx9nYilAwyg42r_D7wclwHL0E-RrRQjAb2GkvsanDGzzKDtbtqQZcDFR3TripMrjY3EatvSekaMDsJ",

  // email sending configuration
  email_auth_user: "athwas@iakashmir.com",
  email_auth_password: "athwas@1001",
  email_auth_service: "gmail",
  email_auth_port: 587,
  email_auth_host: "smtp.gmail.com",
  email_from: "athwas@iakashmir.com",
  email_from_name: "Grocery Admin",

  // customer care and admin email
  adminEmail: "athwas@iakashmir.com",
  customerCareEmail: "athwas@iakashmir.com",

  // email send on exception occured on app crash
  developerEmail: "athwas@iakashmir.com",

  // Twilio SMS
  twilioAccountSid: "ACe55c2eff3879c9f645428b14098ad9d2",
  twilioAuthToken: "de06684460e759c72436ee0a3e97fe72",
  twilioFromPhone: "+18646148913", // +15005550006

  // twilioAccountSid: "AC4a8f0c4eecce60903c3edce8894acc0d",
  // twilioAuthToken: "32591ee7e2431d82e1212e3c7ab5e671",
  // twilioFromPhone: "+12015826914",
  adminid: "5f18295dd364c8608604b992",

  ccAvenu: {
    workingKey: "DBFD4559F790965B098820ACE05333B0",
    accessCode: "AVTL07ID25BH87LTHB",
  },
};
