module.exports = {
  mongoURI:
    "mongodb://footprint:cQZMR[LqbtB8E@3.7.83.168:27089/grocery-live-user-service?authSource=admin",

  expressPort: 3020,
  siteUrl: "http://192.168.1.69:3050",
  rootPath: "/opt/lampp7/htdocs/node/waadpay-ewallet/api-gateway",

  // service base urls
  userServiceUrl: "http://192.168.1.69:3051",
  adminServiceUrl: "http://192.168.1.69:3052",

  // database name
  databaseName: "grocery-user-service",

  // project name
  siteTitle: "Athwas",

  // JWT Secret Key
  jwtSecretKey: "GroceryAppusers",

  // Login session expiration setting for App Users
  appLoginSessionExpiryTime: 24 * 60, // in minutes
  appLoginSessionAuthCheck: true,

  timeZone: "Asia/Kolkata",

  // api key for node-geocoder npm package
  geocoderApiKey: "AIzaSyCnHXmtGqz7eOZg2rW9U20KDit1tRF6rhU",

  // api key for web service access
  apiAccessKey: "Ijefdsyce",

  apiAccessKeyForOther: "IYgshr4f(jiv6",

  validateApiAccess: true,

  // when call services internally, use this key instead of token
  internalApiAccessKey: "3x[aR45]YJRJS}45",

  // Twilio SMS
  twilioAccountSid: "ACe55c2eff3879c9f645428b14098ad9d2",
  twilioAuthToken: "de06684460e759c72436ee0a3e97fe72",
  twilioFromPhone: "+18646148913", // +15005550006
  adminid: "5f18295dd364c8608604b992",
  // Redis Config Options. Ref: https://www.npmjs.com/package/ioredis
  redisConfigOpts: {
    port: 6379,
    host: "127.0.0.1",
    prefix: "grocery_user",
    password:
      "beLJzkzJWmY58bhnq62TKKDawlx1z97yVeLQOn3ZNFG1qrpwaL8Qe9cZzlWi7PcQp1+0ils9v/ahwofY",
    db: 4,
  },
};
