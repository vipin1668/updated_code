'use strict';

const  authMiddleware = require('./authMiddleware');

module.exports = {
     authMiddleware:authMiddleware
}