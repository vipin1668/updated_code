const data = [
  // {
  //   title: "dashboards.total-subadmins",
  //   icon: "iconsminds-network",
  //   value: 14,
  // },
  { title: "dashboards.total-customers", icon: "iconsminds-mens", value: 32 },
  { title: "dashboards.total-drivers", icon: "iconsminds-mens", value: 74 },
  // {
  //   title: "dashboards.total-warehouses",
  //   icon: "iconsminds-clothing-store",
  //   value: 25,
  // },
  // { title: "dashboards.total-brands", icon: "iconsminds-tag-3", value: 25 },
  // { title: "dashboards.total-coupons", icon: "iconsminds-gift-box", value: 25 },
  {
    title: "dashboards.total-business-categories",
    icon: "iconsminds-network",
    value: 25,
  },
  // {
  //   title: "dashboards.total-products",
  //   icon: "iconsminds-shopping-bag",
  //   value: 25,
  // },
  // { title: "dashboards.total-orders", icon: "iconsminds-check", value: 25 },
];
export default data;
