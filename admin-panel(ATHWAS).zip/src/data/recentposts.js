const recentPosts = [
    {
      key: 1,
      title: 'Progressively Extensive Infomediaries',
      thumb: '/assets/img/magdalena-thumb.jpg',
      badge: 'NEW'
    },
    {
      key: 2,
      title: 'Assertively Iterate Resource Maximizing',
      thumb: '/assets/img/marble-cake-thumb.jpg'
    },
    {
      key: 3,
      title: 'Manufactured Products',
      thumb: '/assets/img/salzburger-nockerl-thumb.jpg',
      badge: 'TRENDING'
    },
    {
      key: 4,
      title: 'Podcasting Operational Change',
      thumb: '/assets/img/goose-breast-thumb.jpg'
    },
    {
      key: 5,
      title: 'Performing a Deep Dive',
      thumb: '/assets/img/petit-gateau-thumb.jpg'
    }
  ]
  
  export default recentPosts
  